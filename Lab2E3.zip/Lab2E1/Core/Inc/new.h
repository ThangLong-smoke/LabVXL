/*
 * new.h
 *
 *  Created on: Sep 29, 2023
 *      Author: USER
 */

#ifndef INC_NEW_H_
#define INC_NEW_H_
#include "main.h"
#include "led.h"
void initGPIO();



#endif /* INC_NEW_H_ */
